#!/bin/bash

sudo mkdir /usr/local/dni

sudo dpkg -i dni.deb