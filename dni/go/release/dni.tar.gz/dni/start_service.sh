#!/bin/bash


/usr/local/dni/dni #2>&1 | tee -a /usr/local/snds/panic.log